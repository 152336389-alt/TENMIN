// Minimal Cloudflare Worker that keeps your API key off the website.
// Set secrets: ANTHROPIC_API_KEY, and ALLOWED_ORIGIN (e.g. https://YOURNAME.github.io).
export default {
  async fetch(req, env) {
    const cors = { "Access-Control-Allow-Origin": env.ALLOWED_ORIGIN || "*", "Access-Control-Allow-Headers": "Content-Type" };
    if (req.method === "OPTIONS") return new Response(null, { headers: cors });
    const { prompt } = await req.json();
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: "claude-sonnet-5-5", max_tokens: 800, messages: [{ role: "user", content: String(prompt).slice(0, 8000) }] })
    });
    const d = await r.json();
    const text = (d.content || []).map(c => c.text || "").join("");
    const m = text.match(/\{[\s\S]*\}/);
    return new Response(m ? m[0] : "{}", { headers: { ...cors, "Content-Type": "application/json" } });
  }
};
