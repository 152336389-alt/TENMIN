# Drop your files here

Put images and audio anywhere inside `assets/` (sub-folders are fine). Nothing else to edit.
The site finds files by **name only**, ignoring folder and extension:

| File name | What it does |
|---|---|
| `logo.png` / `.svg` | Replaces the text logo |
| `hero.jpg` / `.webp` | Image beside the landing-page headline |
| `favicon.png` / `.svg` | Browser tab icon |
| `avatar.png` | Tutor avatar in AI Tutor |
| `audio-bongu.mp3` | Recorded pronunciation, played by Listen for the word "Bonġu" |

Audio names are `audio-` plus the word in lower case with accents removed and ħ written as h, e.g. `audio-jekk-jogh-bok.mp3` for "Jekk jogħġbok" (għ becomes gh, ġ becomes g).
