/* ---- Asset loader: drop files anywhere in /assets, reference them by file name only ---- */
const ASSETS={};
const slug=s=>s.normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/ħ/gi,"h").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"");
async function probe(){const ex=["svg","png","webp","jpg","jpeg"];await Promise.all(["logo","hero","favicon","avatar"].flatMap(n=>ex.map(async e=>{try{const r=await fetch(`assets/${n}.${e}`,{method:"HEAD"});if(r.ok&&!ASSETS[n])ASSETS[n]=`assets/${n}.${e}`}catch(_){}})))}
function applyAssets(){
 document.querySelectorAll("img[data-asset]").forEach(el=>{const u=ASSETS[el.dataset.asset.toLowerCase()];if(!u||el.getAttribute("src")===u)return;el.onload=()=>{el.hidden=false;const fb=el.parentElement.querySelector(".fb");if(fb)fb.hidden=true};el.src=u});
 if(ASSETS.favicon){const l=document.getElementById("favicon");if(l)l.href=ASSETS.favicon}
}
fetch("assets/manifest.json",{cache:"no-cache"}).then(r=>r.ok?r.json():Promise.reject()).then(list=>{list.forEach(f=>{const k=f.split("/").pop().replace(/\.[^.]+$/,"").toLowerCase();ASSETS[k]=encodeURI("assets/"+f)})}).catch(probe).then(applyAssets);
const ROUTES=["home","dash","learn","lesson","tutor","vocab","progress"];
const WORDS=[
{mt:"Bonġu",en:"Good morning / hello",pr:"bon-JOO",ex:"Bonġu! Jisimni Sara.",exen:"Good morning! My name is Sara.",cat:"Greetings",lvl:"Beginner"},
{mt:"Bonswa",en:"Good evening",pr:"bon-SWAH",ex:"Bonswa, kif int?",exen:"Good evening, how are you?",cat:"Greetings",lvl:"Beginner"},
{mt:"Kif int?",en:"How are you?",pr:"keef eent",ex:"Kif int illum?",exen:"How are you today?",cat:"Greetings",lvl:"Beginner"},
{mt:"Tajjeb",en:"Good / well",pr:"TAI-yeb",ex:"Tajjeb, grazzi.",exen:"Well, thank you.",cat:"Greetings",lvl:"Beginner"},
{mt:"Grazzi",en:"Thank you",pr:"GRAT-see",ex:"Grazzi ħafna.",exen:"Thank you very much.",cat:"Everyday",lvl:"Beginner"},
{mt:"Jekk jogħġbok",en:"Please",pr:"yek YOJ-bok",ex:"Ilma, jekk jogħġbok.",exen:"Water, please.",cat:"Everyday",lvl:"Beginner"},
{mt:"Skużani",en:"Excuse me / sorry",pr:"skoo-ZAH-nee",ex:"Skużani, grazzi.",exen:"Excuse me, thank you.",cat:"Everyday",lvl:"Beginner"},
{mt:"Iva",en:"Yes",pr:"EE-vah",ex:"Iva, grazzi.",exen:"Yes, thank you.",cat:"Everyday",lvl:"Beginner"},
{mt:"Le",en:"No",pr:"leh",ex:"Le, grazzi.",exen:"No, thank you.",cat:"Everyday",lvl:"Beginner"},
{mt:"Ċaw",en:"Bye",pr:"chow",ex:"Ċaw, narak għada.",exen:"Bye, see you tomorrow.",cat:"Greetings",lvl:"Beginner"},
{mt:"Ilma",en:"Water",pr:"IL-mah",ex:"Ilma, jekk jogħġbok.",exen:"Water, please.",cat:"Food",lvl:"Beginner"},
{mt:"Ħobż",en:"Bread",pr:"hobs",ex:"Nixtieq ħobż, jekk jogħġbok.",exen:"I would like bread, please.",cat:"Food",lvl:"Beginner"},
{mt:"Kafè",en:"Coffee",pr:"kah-FEH",ex:"Kafè, grazzi.",exen:"Coffee, thank you.",cat:"Food",lvl:"Beginner"},
{mt:"Wieħed",en:"One",pr:"WEE-hed",ex:"Wieħed kafè, jekk jogħġbok.",exen:"One coffee, please.",cat:"Numbers",lvl:"Beginner"},
{mt:"Tnejn",en:"Two",pr:"tnayn",ex:"Tnejn kafè, grazzi.",exen:"Two coffees, thank you.",cat:"Numbers",lvl:"Beginner"}
];
const LESSON=[0,1,2,3,4,5,6,10];
const DAYS=["M","T","W","T","F","S","S"];
let S={xp:0,streak:0,learned:[],last:"",week:[0,0,0,0,0,0,0],done:0};
try{const r=localStorage.getItem("tenmin");if(r)S={...S,...JSON.parse(r)}}catch(e){}
const save=()=>{try{localStorage.setItem("tenmin",JSON.stringify(S))}catch(e){}};
const $=s=>document.querySelector(s);
const app=$("#app");
let view="home",st={};
const TABS=[["dash","Dashboard"],["learn","Learn"],["tutor","AI Tutor"],["vocab","Vocabulary"],["progress","Progress"]];

function speak(t){const a=ASSETS["audio-"+slug(t)];if(a){new Audio(a).play().catch(()=>{});return}
  if(!("speechSynthesis" in window))return alert("Audio isn’t supported in this browser.");
  const u=new SpeechSynthesisUtterance(t);u.lang="mt-MT";
  const has=speechSynthesis.getVoices().some(v=>v.lang.toLowerCase().startsWith("mt"));
  if(!has)alert("This device has no Maltese voice installed, so audio may sound wrong. Use the pronunciation guide instead.");
  speechSynthesis.cancel();speechSynthesis.speak(u);
}
function go(v){if(location.hash.slice(1)!==v){location.hash=v;return}view=v;st={};render();window.scrollTo(0,0)}
addEventListener("hashchange",()=>{const v=location.hash.slice(1);if(ROUTES.includes(v)){view=v;st={};render();window.scrollTo(0,0)}});
function esc(s){return s.replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]))}

function renderTabs(){$("#tabs").className=view==="home"?"row":"row bar";
  $("#tabs").innerHTML=view==="home"?`<button class="btn" data-go="dash">Start learning free</button>`:
   TABS.map(([k,l])=>`<button class="tab" data-go="${k}" ${view===k||(view==="lesson"&&k==="learn")?'aria-current="page"':""}>${l}</button>`).join("");
}
function render(){renderTabs();({home,dash,learn,lesson,tutor:tutor2,vocab,progress})[view]();applyAssets()}

function home(){app.innerHTML=`
<section class="hero"><div class="ht"><h1>Learn Maltese in just 10 minutes a day.</h1>
<p class="sub">Your personal Maltese practice companion. Learn useful phrases, build confidence in everyday conversations, and track your streak.</p>
<div class="row"><button class="btn coral" data-go="dash">Start learning free</button><button class="btn ghost" data-go="vocab">Explore lessons</button></div></div><img class="heroimg" data-asset="hero" alt="" decoding="async" hidden></section>
<h2>How a daily session works</h2>
<div class="grid">
${[["Vocabulary","2 min","Flip through new words with pronunciation guides."],["Pronunciation","2 min","Listen and repeat each phrase."],["Sentences","2 min","See each word used in a real sentence."],["Conversation","3 min","Practise a café order with guided replies."],["Quick quiz","1 min","Check what stuck and earn XP."]].map(([a,b,c])=>`<div class="card"><span class="pill">${b}</span><h3 style="margin-top:10px">${a}</h3><p class="mute">${c}</p></div>`).join("")}
</div>
<div class="note"><b>Prototype scope.</b> This build runs fully in your browser: lessons, quizzes, vocabulary search, streaks and XP work and are saved on this device. Accounts and Google sign-in need a secure backend and are planned for the next phases. The AI Tutor uses Claude through this page and is typed-first, with optional voice where your browser supports it.</div>
<h2>Pricing</h2><div class="grid"><div class="card"><h3>Free</h3><p class="mute">One 10-minute lesson a day, vocabulary library, streaks.</p></div><div class="card"><h3>Plus (sample)</h3><p class="mute">Unlimited AI conversations and voice feedback. Pricing to be decided.</p></div></div>`}

function dash(){
 const pct=Math.min(100,Math.round(S.learned.length/WORDS.length*100));
 const today=(new Date().getDay()+6)%7;
 app.innerHTML=`<h1 style="font-size:2.2rem;margin-top:24px">Bonġu! Ready for 10 minutes?</h1>
<div class="grid">
<div class="card"><div class="big">${S.streak}</div><div class="mute">day streak</div></div>
<div class="card"><div class="big">${S.learned.length}</div><div class="mute">words learned</div></div>
<div class="card"><div class="big">${S.xp}</div><div class="mute">XP</div></div></div>
<div class="card"><h3>Today’s lesson: Greetings & café basics</h3>
<p class="mute">8 words, flashcards, a short quiz. About 10 minutes.</p>
<div class="bar" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100"><i style="width:${pct}%"></i></div>
<p class="mute" style="margin:8px 0 16px">${pct}% of the starter library learned</p>
<button class="btn coral" data-go="lesson">${S.last===new Date().toDateString()?"Practise again":"Continue learning"}</button></div>
<div class="card"><h3>This week</h3><div class="week">${DAYS.map((d,i)=>`<div class="${S.week[i]?"on":""}"><span></span>${d}${i===today?" •":""}</div>`).join("")}</div></div>`}

function learn(){app.innerHTML=`<h2 style="margin-top:24px">Learn</h2>
<div class="card"><h3>Daily lesson</h3><p class="mute">Greetings & café basics · 8 words</p><button class="btn" data-go="lesson">Start</button></div>
<div class="card"><h3>Practise a conversation</h3><p class="mute">Order a coffee with guided replies.</p><button class="btn ghost" data-go="tutor">Open AI Tutor</button></div>
<p class="mute">More categories (numbers, transport, workplace, emergencies, healthcare) will be added once the content has been checked against Maltese references.</p>`}

function lesson(){
 if(!st.step){st={step:"cards",i:0,flip:false,q:0,score:0,ans:null}}
 const L=LESSON.map(i=>WORDS[i]);
 if(st.step==="cards"){
  const w=L[st.i];
  app.innerHTML=`<p class="mute" style="margin-top:24px">Step 1 of 2 · Card ${st.i+1} of ${L.length}</p>
  <div class="card flash"><div class="mt">${w.mt}</div>
  <p class="mute" style="margin:6px auto">Say it: <b>${w.pr}</b></p>
  ${st.flip?`<h3>${w.en}</h3><p>${w.ex}<br><span class="mute">${w.exen}</span></p>`:`<button class="btn ghost" id="flip">Show meaning</button>`}
  <div class="row" style="justify-content:center"><button class="btn ghost" id="say">Listen</button></div></div>
  <div class="row"><button class="btn" id="next" ${st.flip?"":"disabled"}>${st.i<L.length-1?"Next word":"Go to quiz"}</button></div>`;
  const f=$("#flip");if(f)f.onclick=()=>{st.flip=true;lesson()};
  $("#say").onclick=()=>speak(w.mt);
  $("#next").onclick=()=>{if(st.i<L.length-1){st.i++;st.flip=false}else st.step="quiz";lesson()};
 }else if(st.step==="quiz"){
  const w=L[st.q];
  const pool=WORDS.filter(x=>x!==w).sort(()=>Math.random()-.5).slice(0,3);
  if(!st.opts||st.optsFor!==st.q){st.opts=[...pool,w].sort(()=>Math.random()-.5);st.optsFor=st.q}
  app.innerHTML=`<p class="mute" style="margin-top:24px">Step 2 of 2 · Question ${st.q+1} of ${L.length}</p>
  <div class="card"><h3>What does “${w.mt}” mean?</h3>
  ${st.opts.map((o,i)=>`<button class="opt ${st.ans!==null?(o===w?"right":(i===st.ans?"wrong":"")):""}" data-o="${i}" ${st.ans!==null?"disabled":""}>${o.en}</button>`).join("")}
  ${st.ans!==null?`<p><b>${st.opts[st.ans]===w?"Correct!":"Not quite."}</b> ${w.mt} (${w.pr}): ${w.ex} – ${w.exen}</p><button class="btn" id="nq">${st.q<L.length-1?"Next question":"Finish"}</button>`:""}</div>`;
  document.querySelectorAll("[data-o]").forEach(b=>b.onclick=()=>{st.ans=+b.dataset.o;if(st.opts[st.ans]===w)st.score++;lesson()});
  const n=$("#nq");if(n)n.onclick=()=>{if(st.q<L.length-1){st.q++;st.ans=null}else{finish();return}lesson()};
 }else{
  app.innerHTML=`<div class="card flash"><div class="mt">Brava!</div><h3>${st.score} of ${L.length} correct · +${st.gain} XP</h3><p class="mute">Streak: ${S.streak} day${S.streak===1?"":"s"}</p><button class="btn coral" data-go="dash">Back to dashboard</button></div>`;
 }
}
function finish(){
 const L=LESSON.map(i=>WORDS[i]);
 st.gain=20+st.score*5;S.xp+=st.gain;
 LESSON.forEach(i=>{if(!S.learned.includes(i))S.learned.push(i)});
 const t=new Date().toDateString();
 if(S.last!==t){const y=new Date(Date.now()-864e5).toDateString();S.streak=S.last===y?S.streak+1:1;S.last=t}
 S.week[(new Date().getDay()+6)%7]=1;save();st.step="done";lesson();
}

const SCRIPT=[
 {t:"Bonġu! (Good morning!)",opts:["Bonġu!","Iva","Ċaw"],good:0,fb:"“Bonġu” is the right greeting back."},
 {t:"Kif nista’ naqdi? (How can I help you?)",opts:["Kafè, jekk jogħġbok.","Ċaw","Le"],good:0,fb:"Ordering with “jekk jogħġbok” is polite."},
 {t:"Xi ħaġa oħra? (Anything else?)",opts:["Le, grazzi.","Bonswa","Iva, ċaw"],good:0,fb:"“Le, grazzi” politely declines."}];
function tutor(){
 if(st.n===undefined)st={n:0,log:[]};
 const s=SCRIPT[st.n];
 app.innerHTML=`<h2 style="margin-top:24px">AI Tutor: ordering at a café</h2>
 <div class="note">This is a <b>scripted practice</b>, not live AI. The real conversation partner needs a secure backend to call a language model, and its Maltese output must be checked before launch.</div>
 <div class="card">${st.log.map(m=>`<div class="bub ${m.u?"u":"t"}">${m.x}</div>`).join("")}
 ${s?`<div class="bub t">${s.t}</div>${s.opts.map((o,i)=>`<button class="opt" data-c="${i}">${o}</button>`).join("")}`:`<p><b>Conversation complete.</b></p><button class="btn" id="again">Restart</button>`}</div>`;
 document.querySelectorAll("[data-c]").forEach(b=>b.onclick=()=>{const i=+b.dataset.c;
  st.log.push({x:s.t},{u:1,x:s.opts[i]},{x:i===s.good?"✓ "+s.fb:"Try a more natural reply: “"+s.opts[s.good]+"”. "+s.fb});st.n++;tutor()});
 const a=$("#again");if(a)a.onclick=()=>{st={};tutor()};
}

function vocab(){
 app.innerHTML=`<h2 style="margin-top:24px">Vocabulary</h2><input type="search" id="q" placeholder="Search Maltese or English" aria-label="Search vocabulary"><div id="list"></div>`;
 const draw=()=>{const q=$("#q").value.toLowerCase();
  $("#list").innerHTML=WORDS.filter(w=>(w.mt+w.en+w.cat).toLowerCase().includes(q)).map(w=>`<div class="card"><div class="row"><b style="font:700 1.3rem Fraunces,serif;color:var(--blue)">${w.mt}</b><span class="pill">${w.cat}</span><span class="pill">${w.lvl}</span><button class="btn ghost" style="padding:6px 14px;margin-left:auto" data-s="${esc(w.mt)}">Listen</button></div><div>${w.en} · <span class="mute">${w.pr}</span></div><div class="mute">${w.ex} – ${w.exen}</div></div>`).join("")||"<p>No matches. Try another word.</p>";
  document.querySelectorAll("[data-s]").forEach(b=>b.onclick=()=>speak(b.dataset.s))};
 $("#q").oninput=draw;draw();
}

function progress(){
 const lv=Math.floor(S.xp/100)+1;
 const badges=[["First lesson",S.xp>0],["3-day streak",S.streak>=3],["10 words",S.learned.length>=10],["100 XP",S.xp>=100]];
 app.innerHTML=`<h2 style="margin-top:24px">Progress</h2><div class="grid"><div class="card"><div class="big">Level ${lv}</div><div class="bar"><i style="width:${S.xp%100}%"></i></div><p class="mute">${100-S.xp%100} XP to next level</p></div><div class="card"><div class="big">${S.learned.length}/${WORDS.length}</div><div class="mute">words mastered</div></div></div>
 <div class="card"><h3>Badges</h3><div class="row">${badges.map(([n,on])=>`<span class="pill" style="${on?"background:var(--coral);color:#2a0d06":"opacity:.5"}">${n}${on?"":" (locked)"}</span>`).join("")}</div></div>
 <button class="btn ghost" id="reset">Reset my progress</button>`;
 $("#reset").onclick=()=>{if(confirm("Reset all progress on this device?")){S={xp:0,streak:0,learned:[],last:"",week:[0,0,0,0,0,0,0],done:0};save();progress()}};
}

let SMP=null;
(async()=>{try{SMP=await window.claude?.use("sample")}catch(e){}
 const ep=(window.TENMIN_CONFIG||{}).tutorEndpoint;
 if(!SMP&&ep)SMP={json:async p=>{const r=await fetch(ep,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt:p})});if(!r.ok)throw{code:"http"};return r.json()}}})();
const SCEN=["Talking with Maltese people","Ordering food in a restaurant","Working in a hotel","Talking with customers","Job interview in Malta","Shopping in a supermarket","Asking for directions","Talking with colleagues","Renting accommodation","Everyday social chat"];
const MODES={beginner:"Beginner: simple Maltese, translations, gentle corrections",normal:"Normal: everyday Maltese, correction after each sentence",challenge:"Challenge: Maltese only, little help, report at the end"};
let T=null;addEventListener("online",()=>T&&!T.ended&&paint());addEventListener("offline",()=>T&&!T.ended&&paint());
const norm=s=>s.toLowerCase().replace(/[^\p{L}\s]/gu,"").replace(/\s+/g," ").trim();
const hasMt=()=>"speechSynthesis" in window&&speechSynthesis.getVoices().some(v=>/^mt/i.test(v.lang));
function enPick(){if(!("speechSynthesis" in window))return null;const vs=speechSynthesis.getVoices().filter(v=>/^en/i.test(v.lang));const m=vs.find(v=>/\b(male|david|daniel|alex|fred|guy|mark|george|james|ryan|thomas|arthur|oliver|rishi|aaron|gordon)\b/i.test(v.name)&&!/female/i.test(v.name));return m?{v:m,male:true}:vs[0]?{v:vs[0],male:false}:null}
function sayEn(force,chained){
 const p=enPick();
 if(!T||T.paused||T.ended||T.busy||!T.enOn||!T.lastEn||!p||(T.muted&&!force)){if(chained&&T&&!T.paused&&!T.ended){T.speaking=false;autoListen()}return false}
 if(!chained)speechSynthesis.cancel();
 if(T.cur)T.cur.onend=null;
 const u=new SpeechSynthesisUtterance(T.lastEn);T.cur=u;u.lang="en-GB";u.voice=p.v;u.rate=T.rate||1;
 u.onend=()=>{if(T){T.speaking=false;autoListen()}};
 T.speaking=true;speechSynthesis.speak(u);return true}
const mtV=()=>"speechSynthesis" in window?speechSynthesis.getVoices().filter(v=>/^mt/i.test(v.lang)):[];
function say(t,force){
 if(!T||(T.muted&&!force))return false;if(!hasMt())return sayEn(force);
 speechSynthesis.cancel();
 if(T.cur)T.cur.onend=null;const u=new SpeechSynthesisUtterance(t);T.cur=u;u.lang="mt-MT";u.rate=T.rate||1;
 const vs=mtV();u.voice=vs.find(v=>v.name===T.vname)||vs[0];
 u.onend=()=>{if(T&&T.enOn&&T.lastEn&&t===T.last)sayEn(force,true);else if(T){T.speaking=false;autoListen()}};
 T.speaking=true;speechSynthesis.speak(u);return true}
function autoListen(){if(T&&!T.ended&&T.auto&&!T.paused&&!T.micOff&&!T.listen&&!T.busy&&!T.speaking)mic()}
function tutor2(){
 if(!SMP){tutor();return}
 if(!T){
  app.innerHTML=`<h2 style="margin-top:24px">AI Tutor</h2><div class="card"><p class="mute">Choose a situation and a mode, then talk or type. You can reply in Maltese or English.</p>
  <p><label>Situation<br><select class="ti" id="sc">${SCEN.map(s=>`<option>${s}</option>`).join("")}</select></label></p>
  <p><label>Mode<br><select class="ti" id="md">${Object.entries(MODES).map(([k,v])=>`<option value="${k}">${v}</option>`).join("")}</select></label></p>
  <p class="mute">Voice mode: after the tutor speaks, your microphone opens automatically and the tutor replies when you stop talking. Speech recognition and voices come from your browser, and Maltese support varies by device.</p><button class="btn coral" id="go2">Start conversation</button></div>
  <div class="note">Corrections come from an AI model, not a verified grammar checker. It can make mistakes in Maltese, so check anything surprising with a teacher or dictionary.</div>`;
  $("#go2").onclick=()=>{T={mode:$("#md").value,sc:$("#sc").value,msgs:[],t0:Date.now(),words:[],n:{c:0,o:0,e:0},busy:false,auto:true,rate:1,sp:0,rp:0,rm:0,idle:0,enOn:true};send("(start the conversation with a greeting and a first question)",true)};
  return}
 paint()}
function msgHtml(m,i){
 if(m.sys)return `<div class="mute" style="margin-bottom:10px">${m.x}</div>`;
 if(m.u){let h=`<div class="bub u">${esc(m.x)}</div>`;
  if(m.fix)h+=`<div class="card sm v-${m.v}"><b>${m.v==="error"?"Good try! Let’s improve that.":"A more natural way to say it"}</b><br>Your sentence: ${esc(m.fix.said)}<br>Suggested: <b>${esc(m.fix.fixed)}</b><br><span class="mute">${esc(m.fix.why||"")}</span><div class="row" style="margin-top:8px"><button class="btn ghost" style="padding:6px 14px" data-say="${i}">Hear it</button><button class="btn ghost" style="padding:6px 14px" data-rep="${i}">Repeat it</button></div></div>`;
  else if(m.v==="correct")h+=`<div class="card sm v-correct mute">Correct. Well done!</div>`;
  return h}
 return `<div class="bub t"><b>${esc(m.mt)}</b>${m.en?`<br><span class="mute">${esc(m.en)}</span>`:""}${m.unsure?`<br><span class="mute">(The tutor isn’t fully sure about this wording.)</span>`:""}</div>`}
function paint(){
 const keep=$("#ti")?$("#ti").value:"";
 app.innerHTML=`<div class="row" style="margin-top:20px"><div class="av" aria-hidden="true"><img data-asset="avatar" alt="" hidden><span class="fb">🧑‍🏫</span></div><div><b>Tutor</b><div class="mute">${T.sc} · ${T.mode}</div></div><div class="row" style="margin-left:auto"><button class="btn ghost" id="mute">${T.muted?"Unmute":"Mute"}</button><button class="btn coral" id="end">End</button></div></div>
 ${hasMt()?"":`<div class="note">No Maltese voice found on this device, so the tutor’s replies are shown as subtitles. The English translation can still be spoken.</div>`}
 <div class="card" style="margin-top:12px">${T.msgs.map(msgHtml).join("")}${T.busy?`<div class="bub t mute">Thinking…</div>`:""}${T.rep?`<div class="note">Now repeat: <b>${esc(T.rep)}</b></div>`:""}${T.err?`<div class="note">${T.err}</div>`:""}</div>
 <div class="row" style="margin-top:12px"><button class="btn ghost" id="pz">${T.paused?"Resume":"Pause"}</button><button class="btn ghost" id="mm">${T.micOff?"Mic on":"Mic off"}</button><button class="btn ghost" id="rp">Repeat last</button><button class="btn ghost" id="en">English voice: ${T.enOn?"On":"Off"}</button><button class="btn ghost" id="sl">${T.rate<1?"Normal speed":"Slow down"}</button><select class="ti" id="sp" aria-label="Speaking speed" style="flex:0 1 150px;min-width:0"><option value=".7" ${T.rate===.7?"selected":""}>Slow</option><option value="1" ${T.rate===1?"selected":""}>Normal</option><option value="1.15" ${T.rate===1.15?"selected":""}>Natural</option></select>${mtV().length>1?`<select class="ti" id="vs" aria-label="Voice" style="flex:0 1 200px;min-width:0">${mtV().map(v=>`<option ${v.name===T.vname?"selected":""}>${esc(v.name)}</option>`).join("")}</select>`:""}</div>
 ${T.enOn?`<div class="mute" style="margin-top:8px">English voice: ${enPick()?esc(enPick().v.name)+(enPick().male?"":" (this device lists no voice I can confirm is male)"):"none found on this device"}</div>`:""}
 <div class="mute" role="status" style="margin-top:8px">${!navigator.onLine?"Offline: reconnect to continue.":T.paused?"Paused":T.listen?"Listening… speak now":T.speaking?"Tutor speaking. Tap Speak to interrupt.":T.busy?"Thinking…":T.micOff?"Mic off: type your reply":"Ready"}</div>
 <div class="wave ${T.listen?"on":""}" aria-hidden="true">${"<i></i>".repeat(9)}</div><div class="mute" id="live" aria-live="polite">${esc(T.interim||"")}</div>
 <div class="row"><input class="ti" id="ti" placeholder="Type in Maltese or English" aria-label="Your message"><button class="btn" id="snd">Send</button><button class="btn ghost" id="mic">${T.listen?"Stop":"Speak"}</button></div>`;
 $("#ti").value=keep;applyAssets();
 $("#ti").onkeydown=e=>{if(e.key==="Enter"){const v=$("#ti").value;$("#ti").value="";send(v)}};
 $("#snd").onclick=()=>{const v=$("#ti").value;$("#ti").value="";send(v)};
 $("#mic").onclick=()=>{T.paused=false;T.micOff=false;T.idle=0;T.speaking=false;mic()};$("#end").onclick=endChat;
 $("#pz").onclick=()=>{T.paused=!T.paused;T.idle=0;if(T.paused){try{T.rec&&T.rec.abort()}catch(e){}speechSynthesis.cancel();T.listen=false;T.speaking=false}paint();if(!T.paused)autoListen()};
 $("#mm").onclick=()=>{T.micOff=!T.micOff;if(T.micOff){try{T.rec&&T.rec.abort()}catch(e){}T.listen=false}paint();if(!T.micOff)autoListen()};
 $("#rp").onclick=()=>{if(T.last&&!say(T.last,true))T.err="No Maltese voice on this device, so the reply can only be read.";paint()};
 $("#en").onclick=()=>{T.enOn=!T.enOn;if(T.cur)T.cur.onend=null;speechSynthesis.cancel();T.speaking=false;paint();autoListen()};
 $("#sl").onclick=()=>{T.rate=T.rate<1?1:.7;paint()};
 $("#sp").onchange=e=>{T.rate=+e.target.value};
 const vsel=$("#vs");if(vsel)vsel.onchange=e=>{T.vname=e.target.value};
 $("#mute").onclick=()=>{T.muted=!T.muted;speechSynthesis.cancel();paint()};
 document.querySelectorAll("[data-say]").forEach(b=>b.onclick=()=>speak(T.msgs[+b.dataset.say].fix.fixed));
 document.querySelectorAll("[data-rep]").forEach(b=>b.onclick=()=>{T.rep=T.msgs[+b.dataset.rep].fix.fixed;paint()});
}
async function send(x,first){
 x=x.trim();if(!x||T.busy)return;
 if("speechSynthesis" in window)speechSynthesis.cancel();
 T.err="";
 const rep=T.rep&&norm(x)===norm(T.rep);
 if(!first)T.msgs.push({u:1,x});
 if(rep)T.msgs.push({sys:1,x:"✓ Nicely repeated!"});
 if(T.rep){T.rp++;if(rep)T.rm++}T.rep=null;T.busy=true;paint();
 const hist=T.msgs.filter(q=>!q.sys).map(q=>q.u?`Learner: ${q.x}`:`Tutor: ${q.mt}`).join("\n");
 const p=`You are a friendly, patient Maltese (Malti) tutor using standard Maltese. Scenario: ${T.sc}. Mode: ${MODES[T.mode]}.\nConversation so far:\n${hist||"(none)"}\n${first?"Start the conversation: greet the learner and ask a first question.":"Respond to the learner's last message."}${rep?" The learner just correctly repeated a corrected sentence: praise briefly and continue.":""}\nReturn ONLY JSON: {\"reply_mt\":\"\",\"reply_en\":\"English translation (empty string in challenge mode)\",\"verdict\":\"correct|natural|error\",\"said\":\"learner's last message\",\"fixed\":\"corrected or more natural Maltese, empty if verdict is correct\",\"why\":\"simple English explanation\",\"new_words\":[{\"mt\":\"\",\"en\":\"\"}],\"unsure\":false}\nRules: Before using error, confirm the sentence is truly wrong in standard Maltese. Accept valid alternatives and colloquial forms; for example 'Jien jisimni Dibyo' is valid (the pronoun is just emphatic), so at most use natural, noting that 'Jisimni Dibyo' is shorter. Use error only for clear grammar or vocabulary mistakes, natural for valid but less idiomatic wording or English input (give the Maltese in fixed), otherwise correct. Gender agreement: adjectives follow the speaker's gender (tajjeb for a man, tajba for a woman, e.g. 'Jien tajjeb' / 'Jien tajba'); you cannot know the learner's gender, so never mark either form wrong; use at most natural and mention both forms. Never invent words; if unsure about a Maltese form, set unsure true and do not correct. Keep the reply to 1-2 short sentences ending with a question. Be encouraging and never embarrass the learner.`;
 try{
  const r=await SMP.json(p,{cache:false});
  const last=[...T.msgs].reverse().find(q=>q.u);
  if(last&&!first){last.v=r.verdict;if(r.verdict==="error")T.n.e++;else if(r.verdict==="natural")T.n.o++;else T.n.c++;if(r.fixed&&r.verdict!=="correct")last.fix={said:r.said||last.x,fixed:r.fixed,why:r.why}}
  (r.new_words||[]).forEach(w=>{if(w.mt&&!T.words.some(k=>k.mt===w.mt))T.words.push(w)});
  T.msgs.push({mt:r.reply_mt,en:r.reply_en,unsure:r.unsure});T.last=r.reply_mt;T.lastEn=r.reply_en||"";T.spoke=say(r.reply_mt);
 }catch(e){
  T.err=e&&e.code==="not_granted"?"Permission to use the AI was declined. Allow it to keep practising.":e&&e.code==="rate_limited"?"Too many requests. Wait a moment and try again.":"The tutor couldn’t reply. Check your connection and send your message again.";
  if(first)T=null;
 }
 if(T&&T.ended){}else if(T){T.busy=false;paint();if(!T.spoke)autoListen()}else tutor2();
}
function mic(){
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){T.err="Speech recognition isn’t available in this browser. Type your reply instead.";paint();return}
 if(T.listen){T.rec.stop();return}
 if("speechSynthesis" in window)speechSynthesis.cancel();
 if(T.cur)T.cur.onend=null;T.speaking=false;const r=new SR();r.lang="mt-MT";r.interimResults=true;r.continuous=false;T.final="";
 r.onresult=e=>{let s="";for(const x of e.results)s+=x[0].transcript;if(!T.fr)T.fr=Date.now();T.interim=s;const l=$("#live");if(l)l.textContent=s;if(e.results[e.results.length-1].isFinal)T.final=s};
 r.onerror=e=>{if(e.error==="no-speech"||e.error==="aborted")return;if(e.error==="not-allowed"||e.error==="language-not-supported"||e.error==="service-not-allowed")T.micOff=true;T.err=e.error==="language-not-supported"?"This browser can’t recognise Maltese. Type your reply instead.":e.error==="not-allowed"?"Microphone access is blocked. Type your reply instead.":"Speech recognition failed. Type your reply instead."};
 r.onend=()=>{if(!T||T.ended)return;T.listen=false;const f=T.final;T.final="";T.interim="";if(T.fr&&f)T.sp+=Date.now()-T.fr;T.fr=0;paint();if(f){T.idle=0;send(f)}else if(T.auto&&!T.paused&&!T.micOff&&!T.err){if(++T.idle>=3){T.paused=true;T.err="Paused because nothing was heard. Press Resume when you’re ready.";paint()}else setTimeout(autoListen,600)}};
 T.rec=r;T.listen=true;try{r.start()}catch(e){T.listen=false}paint();
}
function endChat(){T.ended=true;T.paused=true;
 try{T.rec&&T.rec.abort()}catch(e){}
 if("speechSynthesis" in window)speechSynthesis.cancel();
 const n=T.n,tot=n.c+n.o+n.e,score=tot?Math.round((n.c+.5*n.o)/tot*100):0;
 const mins=Math.max(1,Math.round((Date.now()-T.t0)/60000));
 const fixes=T.msgs.filter(m=>m.fix);
 const g=fixes.filter(m=>m.v==="error");
 app.innerHTML=`<h2 style="margin-top:24px">Conversation report</h2>
 <div class="grid"><div class="card"><div class="big">${tot?score+"%":"–"}</div><div class="mute">learning score</div></div><div class="card"><div class="big">${mins} min</div><div class="mute">duration</div></div><div class="card"><div class="big">${tot}</div><div class="mute">your turns</div></div></div>
 <div class="note">How the score works: each of your turns counts 1 point if correct, ½ if valid but less natural, 0 if it had a clear error. Score = points ÷ turns. It reflects only what you typed or said in this chat.</div>
 <div class="card"><h3>Mistakes</h3><p>${n.e} clear error${n.e===1?"":"s"}, ${n.o} more-natural suggestion${n.o===1?"":"s"}.</p>${fixes.map(m=>`<p>${esc(m.fix.said)} → <b>${esc(m.fix.fixed)}</b><br><span class="mute">${esc(m.fix.why||"")}</span></p>`).join("")||"<p class=\"mute\">No corrections this time.</p>"}</div>
 <div class="card"><h3>New words</h3>${T.words.map(w=>`<p><b>${esc(w.mt)}</b> · ${esc(w.en||"")}</p>`).join("")||"<p class=\"mute\">None recorded.</p>"}</div>
 <div class="card"><h3>Pronunciation and speaking</h3><p>Time with speech detected by the mic: about ${Math.round((T.sp||0)/1000)} s. Repeat attempts matched by the recogniser: ${T.rm} of ${T.rp}.</p><p class="mute">Not assessed. Browser speech recognition can’t reliably judge Maltese pronunciation, so no score is given.</p></div>
 <div class="card"><h3>Suggested next step</h3><p>${g.length?"Review the corrected sentences above, then repeat this situation.":"Try the same situation in Challenge mode, or pick a new one."}</p><button class="btn coral" id="again2">New conversation</button></div>`;
 $("#again2").onclick=()=>{T=null;tutor2()};
}
document.addEventListener("click",e=>{const b=e.target.closest("[data-go]");if(b)go(b.dataset.go)});
$("#logo").onclick=()=>go("home");
$("#logo").onkeydown=e=>{if(e.key==="Enter")go("home")};
{const v=location.hash.slice(1);if(ROUTES.includes(v))view=v}
render();
