# TENMIN – Maltese in 10 minutes a day

Static site (no build step for the app itself). Works at `https://USER.github.io/REPO/` because every path is relative.

## Deploy
1. Create a GitHub repo and upload everything in this folder (keep `.nojekyll` and `.github`).
2. **Settings → Pages → Source: GitHub Actions.**
3. Push to `main`. The workflow lists `assets/` into `assets/manifest.json` and publishes.

## Add images or audio
Drop files into `assets/` and commit. No paths or code to change; see `assets/README.md`.
Without Actions (Source: "Deploy from a branch"), run `node scripts/build-manifest.mjs` and commit `assets/manifest.json`.
Without a manifest, only `logo`, `hero`, `favicon`, `avatar` in the top level of `assets/` are found.

## AI tutor on GitHub Pages
GitHub Pages is static, so the live AI tutor needs a small server to keep your API key secret. Deploy `server-example/worker.js` (e.g. Cloudflare Workers), then put its URL in `config.js` as `tutorEndpoint`. Until then the tutor tab runs a scripted demo.

## Notes
Progress is saved in the browser (localStorage) per device. Maltese content is unreviewed sample data.
