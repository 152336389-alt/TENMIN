// Optional settings. Leave tutorEndpoint empty to use the scripted tutor demo.
// To enable the live AI tutor, deploy server-example/worker.js and paste its URL here.
window.TENMIN_CONFIG = { tutorEndpoint: "" };
