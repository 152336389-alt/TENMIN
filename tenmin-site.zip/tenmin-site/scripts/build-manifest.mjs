// Lists every file in /assets (any sub-folder) into assets/manifest.json.
import { readdirSync, statSync, writeFileSync } from "node:fs";
import { join, relative, basename } from "node:path";
const root = "assets", skip = new Set(["manifest.json", "README.md", ".gitkeep"]);
const walk = d => readdirSync(d).flatMap(n => { const p = join(d, n); return statSync(p).isDirectory() ? walk(p) : [p]; });
const files = walk(root).filter(p => !skip.has(basename(p))).map(p => relative(root, p).split("\\").join("/")).sort();
writeFileSync(join(root, "manifest.json"), JSON.stringify(files, null, 1));
console.log(`assets/manifest.json: ${files.length} file(s)`);
